To run the code, go into the "Code" folder and run the main.py file.

We left code in there that performs the analysis on the RNG player versus
the AI player and vice versa. Whenever the analysis function is called, it will
print out the runtime, total number of turns for the 100 games, and an array of the wins.
The 0th index is player 1 wins, the 1st index is player 2 wins, and the 2nd (last) index are stalemates.

Have fun!